package io.github.semih.constant;

public enum BankType {
    A_BANK,
    B_BANK
}