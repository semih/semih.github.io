package io.github.semih.statement.client;

public interface AccountStatementClient {
    Object getAccountStatements(Object accountStatementRequest);
}
