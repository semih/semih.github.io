package io.github.semih.statement.converter;

import io.github.semih.factory.Converter;
import io.github.semih.statement.dto.AccountStatementResponse;

public class ABankAccountStatementResponseConverter implements Converter<Object, AccountStatementResponse> {
    @Override
    public AccountStatementResponse convert(Object input) {
        // Let's suppose the values are come from the input parameter.
        return new AccountStatementResponse("1234", "A Bank",
                "USD", "2022-04-30", "REF123",
                "1000", "Credit", "Salary Payment",
                "TRX123", "12:30 PM");
    }
}
