package io.github.semih.statement.service;


import io.github.semih.statement.client.AccountStatementClient;

public interface AccountStatementService {
    Object getAccountStatements(AccountStatementClient accountStatementClient, Object accountStatementRequest);
}