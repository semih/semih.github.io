package io.github.semih.statement.facade;


import io.github.semih.constant.BankType;
import io.github.semih.statement.dto.AccountStatementResponse;

public interface AccountStatementFacade {
    AccountStatementResponse getAccountStatements(BankType bankType, String payload);
}
