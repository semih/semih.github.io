package io.github.semih.statement.converter;

import io.github.semih.factory.Converter;
import io.github.semih.statement.dto.AccountStatementResponse;

public class BBankAccountStatementResponseConverter implements Converter<Object, AccountStatementResponse> {
    @Override
    public AccountStatementResponse convert(Object input) {
        // Let's suppose the values are come from the input parameter.
        return new AccountStatementResponse("5678", "B Bank",
                "EUR", "2023-04-30", "REF456",
                "2000", "Debit", "Rent Payment",
                "TRX456", "10:00 AM");
    }
}