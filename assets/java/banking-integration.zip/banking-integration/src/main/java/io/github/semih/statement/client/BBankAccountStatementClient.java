package io.github.semih.statement.client;

import io.github.semih.statement.dto.BBankAccountStatementRequest;

public class BBankAccountStatementClient implements AccountStatementClient {
    private final String webServiceURL;
    private final String authURL;
    private final String clientId;
    private final String clientSecret;
    public BBankAccountStatementClient(String webServiceURL, String authURL, String clientId, String clientSecret) {
        this.webServiceURL = webServiceURL;
        this.authURL = authURL;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    @Override
    public Object getAccountStatements(Object accountStatementRequest) {
        BBankAccountStatementRequest bBankAccountStatementRequest = (BBankAccountStatementRequest) accountStatementRequest;
        return String.format("""
                [A Bank] web service has been invoked with these parameters
                authURL: [%s]
                webServiceURL: [%s]
                clientId: [%s]
                clientSecret: [%s]
                requestPayload: [%s]
                """, authURL, webServiceURL, clientId, clientSecret, bBankAccountStatementRequest);
    }
}