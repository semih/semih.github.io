package io.github.semih.factory;

public interface Factory<T> {
    T build();
}
