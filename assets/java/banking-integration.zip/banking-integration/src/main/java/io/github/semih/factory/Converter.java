package io.github.semih.factory;

public interface Converter<I, O> {
    O convert(I input);
}
