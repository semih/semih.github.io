package io.github.semih.statement.dto;

import lombok.Builder;

@Builder
public record BBankAccountStatementRequest(String accountId,
                                           String startDate,
                                           String endDate,
                                           String currency) {
}
