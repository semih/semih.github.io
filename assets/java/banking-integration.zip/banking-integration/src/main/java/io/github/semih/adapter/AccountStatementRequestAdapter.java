package io.github.semih.adapter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.RuntimeJsonMappingException;
import io.github.semih.constant.BankType;
import io.github.semih.factory.Adapter;
import io.github.semih.statement.dto.ABankAccountStatementRequest;
import io.github.semih.statement.dto.BBankAccountStatementRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountStatementRequestAdapter implements Adapter<Object> {
    private final BankType bankType;
    private final String payload;
    private final ObjectMapper objectMapper = new ObjectMapper();
    public AccountStatementRequestAdapter(BankType bankType, String payload) {
        this.bankType = bankType;
        this.payload = payload;
    }
    // Request is converted to a specific request in adaptee method.
    public Object adaptee() {
        try {
            return switch (bankType) {
                case A_BANK -> objectMapper.readValue(payload, ABankAccountStatementRequest.class);
                case B_BANK -> objectMapper.readValue(payload, BBankAccountStatementRequest.class);
            };
        } catch (JsonProcessingException e) {
            var message = String.format("An error occurred while trying to build the [%s] request.", bankType);
            log.error(message);
            throw new RuntimeJsonMappingException(message);
        }
    }
}
