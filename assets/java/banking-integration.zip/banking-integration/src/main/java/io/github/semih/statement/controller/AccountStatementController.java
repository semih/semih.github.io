package io.github.semih.statement.controller;

import io.github.semih.constant.BankType;
import io.github.semih.statement.dto.AccountStatementResponse;
import io.github.semih.statement.facade.AccountStatementFacade;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/account-statements")
public class AccountStatementController {
    private final AccountStatementFacade accountStatementFacade;

    @GetMapping
    ResponseEntity<AccountStatementResponse> getAccountStatements(@RequestHeader String bankType, @RequestBody String payload) {
        return ResponseEntity.ok(accountStatementFacade.getAccountStatements(BankType.valueOf(bankType), payload));
    }
}
