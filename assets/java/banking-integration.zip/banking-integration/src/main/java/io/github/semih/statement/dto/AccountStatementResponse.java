package io.github.semih.statement.dto;

import lombok.Builder;

@Builder
public record AccountStatementResponse(
        String bankCode,
        String bankName,
        String currencyType,
        String transactionDate,
        String transactionNumber,
        String amount,
        String debitCreditInfo,
        String transactionDescription,
        String transactionCode,
        String transactionTime) {
}