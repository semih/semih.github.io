package io.github.semih.factory;

public interface Adapter<T> {
    T adaptee();
}
