package io.github.semih.statement.dto;

import lombok.Builder;

@Builder
public record ABankAccountStatementRequest(String accountId,
                                           String startDate,
                                           String endDate) {
}
