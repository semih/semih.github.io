package io.github.semih.statement.client;

import io.github.semih.statement.dto.ABankAccountStatementRequest;

public class ABankAccountStatementClient implements AccountStatementClient {

    private final String webServiceURL;
    private final String username;
    private final String password;

    public ABankAccountStatementClient(String webServiceURL, String username, String password) {
        this.webServiceURL = webServiceURL;
        this.username = username;
        this.password = password;
    }

    @Override
    public Object getAccountStatements(Object accountStatementRequest) {
        ABankAccountStatementRequest aBankAccountStatementRequest = (ABankAccountStatementRequest) accountStatementRequest;
        return String.format("""
                [A Bank] web service has been invoked with these parameters
                webServiceURL: [%s]
                username: [%s]
                password: [%s]
                requestPayload: [%s]
                """, webServiceURL, username, password, aBankAccountStatementRequest);
    }
}