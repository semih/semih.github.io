package io.github.semih.statement.factory;

import io.github.semih.constant.BankType;
import io.github.semih.factory.Factory;
import io.github.semih.statement.client.ABankAccountStatementClient;
import io.github.semih.statement.client.AccountStatementClient;
import io.github.semih.statement.client.BBankAccountStatementClient;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountStatementClientFactory implements Factory<AccountStatementClient> {
    private final BankType bankType;
    public AccountStatementClientFactory(BankType bankType) {
        this.bankType = bankType;
    }
    @Override
    public AccountStatementClient build() {
        switch (bankType) {
            case A_BANK -> {
                var username = "a_bank_user";
                var password = "YV9iYW5rcGQ=";
                var webServiceUrl = "soap-service@a_bank.com";
                return new ABankAccountStatementClient(webServiceUrl, username, password);
            }
            case B_BANK -> {
                var authURL = "auth@b_bank.com";
                var webServiceUrl = "rest-service@b_bank.com";
                var clientId = "b_bank_user";
                var clientSecret = "Tl6zBL0xaPF=";
                return new BBankAccountStatementClient(webServiceUrl, authURL, clientId, clientSecret);
            }

            default -> throw new IllegalStateException("Unexpected bankType: " + bankType);
        }
    }
}
