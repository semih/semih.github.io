package io.github.semih.statement.service;

import io.github.semih.statement.client.AccountStatementClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class AccountStatementServiceImpl implements AccountStatementService {

    @Override
    public Object getAccountStatements(AccountStatementClient accountStatementClient, Object accountStatementRequest) {
        return accountStatementClient.getAccountStatements(accountStatementRequest);
    }
}
