package io.github.semih.statement.factory;

import io.github.semih.constant.BankType;
import io.github.semih.factory.Converter;
import io.github.semih.factory.Factory;
import io.github.semih.statement.converter.ABankAccountStatementResponseConverter;
import io.github.semih.statement.converter.BBankAccountStatementResponseConverter;
import io.github.semih.statement.dto.AccountStatementResponse;

public class AccountStatementResponseConverterFactory implements Factory<Converter<Object, AccountStatementResponse>> {
    private final BankType bankType;
    public AccountStatementResponseConverterFactory(BankType bankType) {
        this.bankType = bankType;
    }
    @Override
    public Converter<Object, AccountStatementResponse> build() {
        return switch (bankType) {
            case A_BANK -> new ABankAccountStatementResponseConverter();
            case B_BANK -> new BBankAccountStatementResponseConverter();
        };
    }
}
