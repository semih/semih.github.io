package io.github.semih.statement.facade;

import io.github.semih.adapter.AccountStatementRequestAdapter;
import io.github.semih.constant.BankType;
import io.github.semih.statement.dto.AccountStatementResponse;
import io.github.semih.statement.factory.AccountStatementClientFactory;
import io.github.semih.statement.factory.AccountStatementResponseConverterFactory;
import io.github.semih.statement.service.AccountStatementService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class AccountStatementFacadeImpl implements AccountStatementFacade {
    private final AccountStatementService accountStatementService;

    @Override
    public AccountStatementResponse getAccountStatements(BankType bankType, String payload) {
        var accountStatements = accountStatementService.getAccountStatements(
                new AccountStatementClientFactory(bankType).build(),
                new AccountStatementRequestAdapter(bankType, payload).adaptee());
        log.info("Request has been sent and response has been received from the [{}] external system. {}", bankType, accountStatements);

        var accountStatementResponseConverterFactory = new AccountStatementResponseConverterFactory(bankType);
        var accountStatementResponse = accountStatementResponseConverterFactory.build().convert(accountStatements);
        log.info("Response received from the external system has been converted to the AccountStatementResponse object.");
        return accountStatementResponse;
    }
}
